################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/max7219/bsp_max7219.c 

C_DEPS += \
./BSP/max7219/bsp_max7219.d 

OBJS += \
./BSP/max7219/bsp_max7219.o 

OBJS__QUOTED += \
"BSP\max7219\bsp_max7219.o" 

C_DEPS__QUOTED += \
"BSP\max7219\bsp_max7219.d" 

C_SRCS__QUOTED += \
"../BSP/max7219/bsp_max7219.c" 


