################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/DotMatrix/bsp_DotMatrix.c 

C_DEPS += \
./BSP/DotMatrix/bsp_DotMatrix.d 

OBJS += \
./BSP/DotMatrix/bsp_DotMatrix.o 

OBJS__QUOTED += \
"BSP\DotMatrix\bsp_DotMatrix.o" 

C_DEPS__QUOTED += \
"BSP\DotMatrix\bsp_DotMatrix.d" 

C_SRCS__QUOTED += \
"../BSP/DotMatrix/bsp_DotMatrix.c" 


