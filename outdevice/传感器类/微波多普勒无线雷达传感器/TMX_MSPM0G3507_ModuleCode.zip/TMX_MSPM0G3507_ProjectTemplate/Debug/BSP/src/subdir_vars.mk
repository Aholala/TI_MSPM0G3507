################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/src/bsp_mh100x.c 

C_DEPS += \
./BSP/src/bsp_mh100x.d 

OBJS += \
./BSP/src/bsp_mh100x.o 

OBJS__QUOTED += \
"BSP\src\bsp_mh100x.o" 

C_DEPS__QUOTED += \
"BSP\src\bsp_mh100x.d" 

C_SRCS__QUOTED += \
"../BSP/src/bsp_mh100x.c" 


