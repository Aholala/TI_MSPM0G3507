################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/scr/bsp_irdistance.c 

C_DEPS += \
./BSP/scr/bsp_irdistance.d 

OBJS += \
./BSP/scr/bsp_irdistance.o 

OBJS__QUOTED += \
"BSP\scr\bsp_irdistance.o" 

C_DEPS__QUOTED += \
"BSP\scr\bsp_irdistance.d" 

C_SRCS__QUOTED += \
"../BSP/scr/bsp_irdistance.c" 


