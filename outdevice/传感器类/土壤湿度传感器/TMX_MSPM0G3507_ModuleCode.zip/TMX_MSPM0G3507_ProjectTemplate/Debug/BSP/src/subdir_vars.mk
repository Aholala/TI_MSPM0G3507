################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/src/bsp_soilhumidity.c 

C_DEPS += \
./BSP/src/bsp_soilhumidity.d 

OBJS += \
./BSP/src/bsp_soilhumidity.o 

OBJS__QUOTED += \
"BSP\src\bsp_soilhumidity.o" 

C_DEPS__QUOTED += \
"BSP\src\bsp_soilhumidity.d" 

C_SRCS__QUOTED += \
"../BSP/src/bsp_soilhumidity.c" 


