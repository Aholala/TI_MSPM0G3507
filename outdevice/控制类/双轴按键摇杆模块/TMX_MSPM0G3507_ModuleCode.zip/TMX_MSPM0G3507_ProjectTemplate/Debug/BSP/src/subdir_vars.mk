################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/src/bsp_joystick.c 

C_DEPS += \
./BSP/src/bsp_joystick.d 

OBJS += \
./BSP/src/bsp_joystick.o 

OBJS__QUOTED += \
"BSP\src\bsp_joystick.o" 

C_DEPS__QUOTED += \
"BSP\src\bsp_joystick.d" 

C_SRCS__QUOTED += \
"../BSP/src/bsp_joystick.c" 


