################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/src/bsp_ir_receiver.c 

C_DEPS += \
./BSP/src/bsp_ir_receiver.d 

OBJS += \
./BSP/src/bsp_ir_receiver.o 

OBJS__QUOTED += \
"BSP\src\bsp_ir_receiver.o" 

C_DEPS__QUOTED += \
"BSP\src\bsp_ir_receiver.d" 

C_SRCS__QUOTED += \
"../BSP/src/bsp_ir_receiver.c" 


